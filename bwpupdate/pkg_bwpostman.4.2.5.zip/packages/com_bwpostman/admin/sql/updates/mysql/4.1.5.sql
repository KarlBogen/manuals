/* Placeholder file for database changes for version 4.1.5 to satisfy Joomla!'s extensions installer */
