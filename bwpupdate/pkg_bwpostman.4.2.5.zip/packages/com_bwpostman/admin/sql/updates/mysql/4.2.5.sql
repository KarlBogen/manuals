/* Placeholder file for database changes for version 4.2.5 to satisfy Joomla!'s extensions installer */
