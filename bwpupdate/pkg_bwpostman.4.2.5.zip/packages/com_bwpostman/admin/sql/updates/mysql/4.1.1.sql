/* Placeholder file for database changes for version 4.1.1 to satisfy Joomla!'s extensions installer */
