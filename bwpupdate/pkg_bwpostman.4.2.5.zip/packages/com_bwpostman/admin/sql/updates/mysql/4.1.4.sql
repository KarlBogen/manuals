/* Placeholder file for database changes for version 4.1.4 to satisfy Joomla!'s extensions installer */
