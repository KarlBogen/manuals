/* Placeholder file for database changes for version 4.1.0 to satisfy Joomla!'s extensions installer */
