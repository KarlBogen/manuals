DROP TABLE IF EXISTS
`#__bwpostman_campaigns`,
`#__bwpostman_campaigns_mailinglists`,
`#__bwpostman_mailinglists`,
`#__bwpostman_newsletters`,
`#__bwpostman_newsletters_mailinglists`,
`#__bwpostman_sendmailcontent`,
`#__bwpostman_sendmailqueue`,
`#__bwpostman_subscribers`,
`#__bwpostman_subscribers_mailinglists`,
`#__bwpostman_templates`,
`#__bwpostman_templates_tpl`,
`#__bwpostman_templates_tags`;
