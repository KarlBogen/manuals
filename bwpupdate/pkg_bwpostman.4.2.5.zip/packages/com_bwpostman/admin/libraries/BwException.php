<?php
/**
 * BwPostman Newsletter Component
 *
 * BwPostman basic exception class.
 *
 * @version 4.2.5
 * @package BwPostman-Admin
 * @author Romana Boldt
 * @copyright (C) 2023 Boldt Webservice <forum@boldt-webservice.de>
 * @support https://www.boldt-webservice.de/en/forum-en/forum/bwpostman.html
 * @license GNU/GPL, see LICENSE.txt
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

namespace BoldtWebservice\Component\BwPostman\Administrator\Libraries;

use Exception;

defined('JPATH_PLATFORM') or die;

/**
 * Basic exception class implemented by every exception of BwPostman
 *
 * @since       2.0.0
 */
class BwException extends Exception
{
//	public function errorMessage() {
//		$errorMsg = $this->getMessage();
//		return $errorMsg;
}
